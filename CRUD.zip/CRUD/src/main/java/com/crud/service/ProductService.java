package com.crud.service;

import java.util.List;
import java.util.Optional;

import com.crud.model.Product;

public interface ProductService {
   
	List<Product> findAll() throws Exception;
	Optional<Product> findById(int id);
    Product saveProduct(Product product)throws Exception;
    void deleteById(int id);
	 
}
