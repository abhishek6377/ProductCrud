package com.crud.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.ProductRepository;
import com.crud.model.Product;


@Service
public class ProductServiceImp implements ProductService {
	
	 @Autowired
	 ProductRepository productRepository;

	@Override
	public List<Product> findAll() throws Exception {
		return productRepository.findAll();
	}

	@Override 
	public Optional<Product> findById(int id) {
		 return  productRepository.findById(id);
	}

	@Override
	public Product saveProduct(Product product) throws Exception {
		if(product!=null) {
			return productRepository.save(product);
		}
		return null;
	}

	@Override
	public void deleteById(int id) {
          productRepository.deleteById(id);
	}

	

}
